function dowloadPDF(){
    const item = document.querySelector(".pdf");

    var opt ={
        margin: 1,
        filename: "pdf",
        html2canvas: { scale: 2 },
        jsPDF: { unit: "in", format: "letter", orientation: "portrait"},
    };
    html2pdf().set(opt).from(item).save();
}