<footer class="bg-light text-center text-lg-start">
  <!-- Copyright -->
  <!-- <div class="text-center p-3" style="color:white; background-color: black;">
    © 2020 Copyright:
    www.HT.cl
  </div> -->
  <!-- Copyright -->
</footer>