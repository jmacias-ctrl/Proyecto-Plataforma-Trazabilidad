<?php
    $server = "localhost";
    $user = "root";
    $password = "";
    $database = "tis";
    
    $conexion = mysqli_connect($server, $user, $password, $database);
?> 